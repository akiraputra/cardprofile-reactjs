import './App.css';
import Cardprofile from './component/Cardprofile';

function App() {
  return (
  <Cardprofile />
  );
}

export default App;
